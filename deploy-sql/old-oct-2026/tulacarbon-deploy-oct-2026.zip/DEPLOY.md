# Tula Carbon: cPanel showcase deploy (MySQL)

Everything is in this folder: backend API (/api), frontend (public/), settings (private/.env)
and the data from local testing (private/seed-data.json). No cPanel environment variables needed.

## 1. Setup Node.js App, then Create
- Node.js version: highest offered, at least 20.19
- Application mode: Production
- Application root: tulacarbon.kaphi.in
- Application URL: tulacarbon.kaphi.in
- Application startup file: app.cjs

## 2. Upload
Upload tulacarbon-deploy.zip into the tulacarbon.kaphi.in folder and Extract it there.
app.cjs must sit directly in that folder. Keep the existing .htaccess (cPanel's).

## 3. Check private/.env
Only DATABASE_URL may need a change: if the database user under "MySQL Databases > Current Users"
is not exactly kaphimosol9_tulacarbon_admin, put the real name there.

## 4. Terminal (paste the "source .../activate" command from the Node.js app page first)
cd ~/tulacarbon.kaphi.in
npm install                       # installs packages
npm run mysql:setup               # creates the tables
npm run data:import:prod          # loads organisations, facilities, boundaries, … from local testing
npm run platform:bootstrap:prod   # creates your real Super Admin
npm run demo:seed:prod            # creates the quick-login demo accounts

Then click Restart on the Node.js app. Each command is safe to run again.

## 5. Open https://tulacarbon.kaphi.in
- Quick login: "Continue as Super Admin" or "Continue as Tenant Admin".
- Real admin: the BOOTSTRAP_ADMIN email and password in private/.env (two-step set up on first sign-in).
- Imported users (naruto@…, etc.) have new random passwords. Reset them from Platform > Users if needed.

## Security
private/, dist/, prisma/ and scripts/ each contain a .htaccess that blocks web access.
Check: https://tulacarbon.kaphi.in/private/.env must NOT show the file.
To end the showcase quick logins: delete DEMO_MODE=true from private/.env and Restart.
