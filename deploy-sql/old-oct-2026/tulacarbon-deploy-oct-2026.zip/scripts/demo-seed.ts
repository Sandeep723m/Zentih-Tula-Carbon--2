// Creates the showcase demo accounts used by the quick-login buttons (DEMO_MODE=true).
//   npm run demo:seed        (or demo:seed:prod on the server)
// Safe to run repeatedly. Passwords are random and never shown: these accounts are reached only
// through quick login. Re-running restores them if someone changed their role or deactivated them.
import { randomBytes } from 'node:crypto'
import { hashPassword } from '../src/auth/crypto.js'
import { getPrisma } from '../src/config/database.js'
import { env } from '../src/config/env.js'

const db = getPrisma()
const account = async (email: string, name: string, platformRole: 'SUPER_ADMIN' | null) => {
  const data = { name, platformRole, isActive: true, mustChangePassword: false, mfaEnabled: false, mfaSecret: null, mfaLastStep: null, failedLoginCount: 0, lockedUntil: null }
  return db.user.upsert({
    where: { email },
    update: data,
    create: { email, passwordHash: await hashPassword(randomBytes(24).toString('base64url')), ...data },
  })
}

await account(env.DEMO_SUPER_EMAIL, 'Demo Super Admin', 'SUPER_ADMIN')
const tenant = await account(env.DEMO_TENANT_EMAIL, 'Demo Tenant Admin', null)

await (await db.organization.findFirst({ where: { name: 'Demo Company' } }))
  ?? await db.organization.create({ data: { name: 'Demo Company', country: 'India', subscription: { create: { planName: 'Showcase', status: 'ACTIVE', startDate: new Date() } } } })
// Tenant Admin of every organisation (incl. imported ones), so quick login can show all showcase data.
for (const { id } of await db.organization.findMany({ select: { id: true } })) {
  await db.membership.upsert({
    where: { userId_organizationId: { userId: tenant.id, organizationId: id } },
    update: { role: 'TENANT_ADMIN' },
    create: { userId: tenant.id, organizationId: id, role: 'TENANT_ADMIN' },
  })
}

console.log(`Demo accounts ready: ${env.DEMO_SUPER_EMAIL} (Super Admin), ${env.DEMO_TENANT_EMAIL} (Tenant Admin of every organisation).`)
if (!env.DEMO_MODE) console.log('Quick login is OFF. Set DEMO_MODE=true to show the buttons.')
await db.$disconnect()
