process.chdir(__dirname)
import('./dist/src/server.js')
