// Resets ONE organisation's working data and loads the end-to-end test scenario (docs/test-scenario.md):
// facilities with grid regions, an approved boundary, FY2024-25, sources for every
// calculation, and every test record submitted by the demo Data Entry user, ready for review.
//   npm run demo:seed && npx tsx scripts/test-scenario.ts "WebAnatomy" --yes
//   (server: npm run demo:seed:prod && node dist/scripts/test-scenario.js "WebAnatomy" --yes)
// Creates the organisation if it does not exist, and gives each demo account its role in it.
// Deletes that organisation's facilities, periods, sources, records, evidence, boundary, runs and
// queries. Keeps the organisation, its users and the audit log (append-only). Not for production data.
import { getPrisma } from '../src/config/database.js'
import { DEMO_ACCOUNTS } from '../src/controllers/demo.controller.js'
import { writeAudit } from '../src/services/audit.js'
import { storage } from '../src/storage/index.js'

const [name, yes] = process.argv.slice(2)
if (!name || yes !== '--yes') {
  console.error('Usage: tsx scripts/test-scenario.ts "<organisation name>" --yes   (wipes that organisation\'s data)')
  process.exit(1)
}
const db = getPrisma()
const org = await db.organization.findFirst({ where: { name } })
  ?? await db.organization.create({ data: { name, country: 'India', subscription: { create: { planName: 'Showcase', status: 'ACTIVE', startDate: new Date() } } } })
const [entry, tenant, verifier] = await Promise.all(
  [DEMO_ACCOUNTS.entry, DEMO_ACCOUNTS.tenant, DEMO_ACCOUNTS.verifier].map((a) => db.user.findUnique({ where: { email: a.email() } })),
)
if (!entry || !tenant || !verifier) throw new Error('Demo accounts missing: run npm run demo:seed first')
const organizationId = org.id
for (const a of Object.values(DEMO_ACCOUNTS)) {
  if (!a.role) continue
  const u = await db.user.findUnique({ where: { email: a.email() } })
  if (u) await db.membership.upsert({ where: { userId_organizationId: { userId: u.id, organizationId } }, update: { role: a.role }, create: { userId: u.id, organizationId, role: a.role } })
}

// ---- wipe (children first) ----
const files = await db.evidence.findMany({ where: { organizationId }, select: { storageKey: true } })
await db.$transaction([
  db.verificationQuery.deleteMany({ where: { organizationId } }), // messages cascade
  db.verifierGrant.deleteMany({ where: { organizationId } }),
  db.periodLockEvent.deleteMany({ where: { organizationId } }),
  db.calculationResult.deleteMany({ where: { organizationId } }),
  db.calculationRun.deleteMany({ where: { organizationId } }),
  db.activityReview.deleteMany({ where: { organizationId } }),
  db.evidence.deleteMany({ where: { organizationId } }),
  db.activityRecord.deleteMany({ where: { organizationId } }),
  db.emissionSource.deleteMany({ where: { organizationId } }),
  db.orgBoundary.deleteMany({ where: { organizationId } }),
  db.reportingPeriod.deleteMany({ where: { organizationId } }),
  db.facility.deleteMany({ where: { organizationId } }),
])
for (const f of files) await storage.remove(f.storageKey).catch(() => {})

// ---- setup (guide step 0) ----
const plant = (code: string, name: string, gridLocation: string, equityShare: number) =>
  db.facility.create({ data: { organizationId, code, name, country: 'India', gridLocation, equityShare, scope1Active: true, scope2Active: true } })
const a = await plant('PA', 'Plant A', 'India - National Average', 100)
const b = await plant('PB', 'Plant B', 'India - Southern Grid', 40)
await db.orgBoundary.create({
  data: {
    organizationId, version: 1, approach: 'EQUITY', status: 'APPROVED', effectiveFrom: new Date('2024-04-01'), baseYear: 2024,
    approvedAt: new Date(), changeReason: 'Test scenario',
    snapshot: [a, b].map((f) => ({ id: f.id, code: f.code, name: f.name, country: f.country, gridLocation: f.gridLocation, equityShare: Number(f.equityShare), operationalControl: null, financialControl: null, scope1Active: true, scope2Active: true })),
  },
})
const fy25 = await db.reportingPeriod.create({ data: { organizationId, name: 'FY2024-25', startDate: new Date('2024-04-01'), endDate: new Date('2025-03-31') } })

const src = (facilityId: string, name: string, category: 'PURCHASED_ELECTRICITY' | 'FUEL_COMBUSTION' | 'FUGITIVE_GAS' | 'PURCHASED_ENERGY' | 'PROCESS' | 'REMOVAL', activityCode: string) =>
  db.emissionSource.create({ data: { organizationId, facilityId, name, category, activityCode } })
const S = {
  gridA: await src(a.id, 'Grid A', 'PURCHASED_ELECTRICITY', 'A-GRID'),
  gridB: await src(b.id, 'Grid B', 'PURCHASED_ELECTRICITY', 'A-GRID'),
  dg: await src(a.id, 'DG set', 'FUEL_COMBUSTION', 'A-ST-DIESEL-GAS-OIL'),
  gas: await src(a.id, 'Gas boiler', 'FUEL_COMBUSTION', 'A-ST-NATURAL-GAS'),
  coal: await src(a.id, 'Coal boiler', 'FUEL_COMBUSTION', 'A-COAL'),
  wood: await src(a.id, 'Biomass boiler', 'FUEL_COMBUSTION', 'A-ST-WOOD-WOOD-WASTE'),
  truck: await src(a.id, 'Truck fleet', 'FUEL_COMBUSTION', 'A-MO-DIESEL'),
  car: await src(a.id, 'Car fleet', 'FUEL_COMBUSTION', 'A-MO-PETROL-GASOL'),
  chiller: await src(a.id, 'Chiller', 'FUGITIVE_GAS', 'A-FU-R-410A'),
  ac: await src(a.id, 'AC units', 'FUGITIVE_GAS', 'A-FU-R-134A'),
  switchgear: await src(a.id, 'Switchgear', 'FUGITIVE_GAS', 'A-FU-SF6'),
  steam: await src(a.id, 'Steam supply', 'PURCHASED_ENERGY', 'A-STEAM'),
  kiln: await src(b.id, 'Clinker kiln', 'PROCESS', 'A-PR-CEMENT-CLINK-PRODU'),
  lime: await src(b.id, 'Lime kiln', 'PROCESS', 'A-PR-LIME-PRODU'),
  recovery: await src(a.id, 'CO2 recovery plant', 'REMOVAL', 'A-CO2-REC'),
}

// ---- records: [guide step, source, quantity, unit, parameters, expected, period, dates] ----
// A source with two records gets two half-years: one source cannot have two submissions over the same days (V-07).
const H1: [string, string] = ['2024-04-01', '2024-09-30']
const H2: [string, string] = ['2024-10-01', '2025-03-31']
type Row = [string, keyof typeof S, string, string, Record<string, string>, string, string?, [string, string]?]
const rows: Row[] = [
  ['1.1', 'gridA', '1200000', 'kWh', {}, 'C-06 852.000 and C-07 852.000 (Q-02)', undefined, H1],
  ['1.2', 'gridB', '500', 'MWh', { instrumentMWh: '300', instrumentType: 'I-REC', instrumentReference: 'IREC-001' }, 'C-06 355.000 (R-09 fallback), C-07 142.000', undefined, H1],
  ['2.1', 'dg', '10000', 'l', { density: '0.84', densityUnit: 'kg/l' }, '26.856', undefined, H1],
  ['2.2', 'gas', '120000', 'SCM', { density: '0.717', densityUnit: 'kg/m3' }, '231.924', undefined, H1],
  ['2.3', 'gas', '500000', 'kWh', { energyBasis: 'GCV' }, '90.975 (V-06)', undefined, H2],
  ['2.4', 'coal', '1250', 't', {}, '3,073.667 (R-03)'],
  ['2.5', 'wood', '200', 't', {}, '5.934 + 349.440 t biogenic CO2 memo'],
  ['2.6', 'truck', '1000', 'l', { density: '0.84', densityUnit: 'kg/l' }, '2.719'],
  ['2.7', 'car', '12000', 'km', { fuelEconomy: '12', density: '0.74', densityUnit: 'kg/l' }, '2.333'],
  ['3.1', 'chiller', '12', 'kg', { method: 'MASS_BALANCE' }, '27.066'],
  ['3.2', 'ac', '50', 'kg', { method: 'SCREENING', leakRate: '0.1' }, '7.650 (J-07)'],
  ['3.3', 'switchgear', '0', 'kg', { method: 'MASS_BALANCE', disposedKg: '20', recoveredKg: '18' }, '50.400', undefined, H1],
  ['4 RETURN', 'gridA', '999', 'MWh', {}, 'Return it ("Invoice shows 950"), correct to 950 as Data Entry, resubmit, approve', undefined, H2],
  ['5.1 STEAM', 'steam', '8000', 'GJ', { supplierFactor: '60', supplierDisclosure: 'Supplier disclosure FY2024-25' }, 'C-21 480.000 (R-11 confirm the supplier factor)'],
  ['5.2 PROCESS', 'kiln', '100000', 't', {}, 'C-04 52,000.000 tCO2 (EF-0308, R-12 confirm the IPCC default)'],
  ['5.3 PROCESS', 'lime', '1000', 't', { factorCode: 'EF-0309' }, 'C-04 750.000 (high-calcium lime, EF-0309)'],
  ['5.4 REMOVAL', 'recovery', '500', 't', { meterReference: 'Recovery meter M-1', endUse: 'Sold to a beverage plant' }, 'C-08 500.000 removal, never netted (J-05 confirm the end use)'],
]

const submittedAt = new Date()
for (const [step, key, quantity, unit, parameters, expected, period, dates] of rows) {
  const p = fy25
  const [startDate, endDate] = dates ? dates.map((d) => new Date(d)) : [p.startDate, p.endDate]
  const s = S[key]
  const r = await db.activityRecord.create({
    data: {
      organizationId, facilityId: s.facilityId, reportingPeriodId: p.id, emissionSourceId: s.id,
      startDate, endDate, quantity, unit, parameters: Object.keys(parameters).length ? parameters : undefined,
      notes: `[Test ${step}] Expected: ${expected}`,
      status: 'SUBMITTED', submittedAt, createdById: entry.id, updatedById: entry.id,
    },
  })
  await db.activityReview.create({ data: { organizationId, activityRecordId: r.id, action: 'SUBMITTED', fromStatus: 'DRAFT', toStatus: 'SUBMITTED', actorId: entry.id } })
}

for (const p of [fy25]) await db.verifierGrant.create({ data: { organizationId, userId: verifier.id, reportingPeriodId: p.id, grantedById: tenant.id } })
await writeAudit({ organizationId, actorUserId: tenant.id, action: 'test_scenario.loaded', entityType: 'Organization', entityId: organizationId, after: { records: rows.length } })

console.log(`"${name}": reset and loaded the test scenario: 2 facilities, approved boundary v1, FY2024-25, ${Object.keys(S).length} sources, ${rows.length} submitted records.`)
await db.$disconnect()
