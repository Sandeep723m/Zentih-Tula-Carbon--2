// Creates the showcase demo accounts used by the quick-login buttons (DEMO_MODE=true).
//   npm run demo:seed        (or demo:seed:prod on the server)
// Safe to run repeatedly. Passwords are random and never shown: these accounts are reached only
// through quick login. Re-running restores them if someone changed their role or deactivated them.
import { randomBytes } from 'node:crypto'
import { hashPassword } from '../src/auth/crypto.js'
import { getPrisma } from '../src/config/database.js'
import { env } from '../src/config/env.js'
import { DEMO_ACCOUNTS } from '../src/controllers/demo.controller.js'

const db = getPrisma()
const account = async (email: string, name: string, platformRole: 'SUPER_ADMIN' | null) => {
  const data = { name, platformRole, isActive: true, mustChangePassword: false, mfaEnabled: false, mfaSecret: null, mfaLastStep: null, failedLoginCount: 0, lockedUntil: null }
  return db.user.upsert({
    where: { email },
    update: data,
    create: { email, passwordHash: await hashPassword(randomBytes(24).toString('base64url')), ...data },
  })
}

await account(env.DEMO_SUPER_EMAIL, 'Demo Super Admin', 'SUPER_ADMIN')
const users = []
for (const a of Object.values(DEMO_ACCOUNTS)) if (a.role) users.push({ role: a.role, user: await account(a.email(), `Demo ${a.label}`, null) })
const tenant = users.find((u) => u.role === 'TENANT_ADMIN')!.user

await (await db.organization.findFirst({ where: { name: 'Demo Company' } }))
  ?? await db.organization.create({ data: { name: 'Demo Company', country: 'India', subscription: { create: { planName: 'Showcase', status: 'ACTIVE', startDate: new Date() } } } })
// Each demo role in every organisation (incl. imported ones), so quick login shows all showcase data;
// the demo verifier is granted every reporting period.
for (const { id } of await db.organization.findMany({ select: { id: true } })) {
  for (const { role, user } of users) {
    await db.membership.upsert({
      where: { userId_organizationId: { userId: user.id, organizationId: id } },
      update: { role },
      create: { userId: user.id, organizationId: id, role },
    })
  }
}
const verifier = users.find((u) => u.role === 'VERIFIER')!.user
for (const p of await db.reportingPeriod.findMany({ select: { id: true, organizationId: true } })) {
  await db.verifierGrant.upsert({
    where: { userId_reportingPeriodId: { userId: verifier.id, reportingPeriodId: p.id } },
    update: {},
    create: { userId: verifier.id, reportingPeriodId: p.id, organizationId: p.organizationId, grantedById: tenant.id },
  })
}

console.log(`Demo accounts ready: Super Admin, ${users.map((u) => u.role).join(', ')} in every organisation.`)
if (!env.DEMO_MODE) console.log('Quick login is OFF. Set DEMO_MODE=true to show the buttons.')
await db.$disconnect()
